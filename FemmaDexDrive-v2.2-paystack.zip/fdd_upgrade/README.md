# FEMADEXDRIVE v2.1 — frontend + backend

This is the upgraded version of the supplied FemmaDexDrive project. It is split into:

- `frontend/` — React/Vite responsive customer, rider, tracking and operations UI.
- `backend/` — Netlify serverless functions for secure routing, order creation, Paystack checkout, Paystack webhook verification, public tracking and admin email notifications.
- `backend/supabase/migrations/001_femmadexdrive_v2.sql` — database schema, RLS, delivery state machine, rider approval, storage bucket and realtime setup.
- `netlify.toml` — deploys the frontend and backend functions together.

## What was upgraded

### Customer
- Signup/login through Supabase Auth.
- Server-side road-distance calculation.
- Weight + package size + dimensions.
- Motorcycle/car/van/lorry recommendation.
- Server-side pricing so the browser cannot change the price calculation.
- Admin price-review stage before payment.
- Real Paystack checkout redirect.
- Payment is only considered paid after Paystack verification/webhook.
- Permanent tracking number.
- Public tracking without login, with limited information.
- Customer delivery dashboard.
- Customer/rider realtime chat.

### Rider
- Rider signup/application.
- Vehicle type + plate.
- Bike/vehicle and identity-document upload area after account creation.
- Pending-review state.
- Admin approval/rejection.
- Online/offline presence.
- Paid delivery requests.
- Atomic acceptance so two riders cannot claim the same order.
- Rider sees package/vehicle/distance information, not the customer's delivery charge.
- Delivery stages: accepted → picked up → on the way → at destination → delivered.

### Admin
- Admin/supervisor role controlled in Supabase.
- Production admin host restriction using `VITE_ADMIN_HOST`.
- Delivery activity feed.
- Full delivery details.
- Price adjustment.
- Rider application approval.
- Payment status.
- Rider availability.
- Realtime order updates.

### Email
Important delivery/payment events can be emailed to `femmadexmanagement@gmail.com` using Resend.
Supabase remains the searchable source of truth; email is an additional operational record/notification.

## Paystack

The backend uses Paystack's server-side Checkout Redirect flow. The secret key is never sent to the browser.

Required Netlify variables:

- `PAYSTACK_SECRET_KEY`
- `PAYSTACK_CALLBACK_URL`
- `PAYSTACK_CALLBACK_URL`

For live payments, use your Paystack live secret key. During development, use the appropriate Paystack test credentials.

Paystack's webhook endpoint must be publicly reachable. Configure the Paystack webhook URL as:

`https://YOUR-NETLIFY-SITE.netlify.app/.netlify/functions/paystack-webhook`

The redirect URL is:

`https://YOUR-NETLIFY-SITE.netlify.app/payment-result`

The webhook verifies `x-paystack-signature` with HMAC SHA-512 before changing an order to paid.

## Routing / distance

Set:

`ORS_API_KEY=...`

The backend geocodes the two addresses and sends their coordinates to OpenRouteService driving directions. It stores the resulting road distance and estimated driving time.

Do not replace this with a browser-provided distance. The backend recalculates it.

## Admin account and password

No admin password is stored in this project. Create the one operations account in Supabase Auth with your chosen strong password, then run `backend/supabase/ADMIN_SETUP.sql` to promote `femmadexmanagement@gmail.com` to the `admin` role. The frontend does not expose a password or admin secret.

## Security

See `SECURITY.md`. The application uses server-side secrets, Supabase RLS, private rider-document storage, Paystack webhook verification, atomic rider acceptance, vehicle eligibility checks, security headers and participant-only chat. No web application can honestly guarantee that it is impossible to hack.

## Supabase setup

1. Create a Supabase project.
2. Open SQL Editor.
3. Run `backend/supabase/migrations/001_femmadexdrive_v2.sql`.
4. Create/confirm your Auth settings.
5. Create your first admin account through Supabase Auth or the app.
6. Promote that account once:

`update public.profiles set role='admin' where id='YOUR_AUTH_USER_UUID';`

Do not put the admin password in source code.

The migration creates a private `rider-documents` storage bucket.

## Netlify variables

Copy `.env.example` into your Netlify environment configuration.

Browser variables:

- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`
- `VITE_ADMIN_HOST`
- `VITE_SUPPORT_PHONE`

Server-only variables:

- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `APP_ORIGIN`
- `PAYSTACK_SECRET_KEY`
- `PAYSTACK_CALLBACK_URL`
- `PAYSTACK_CALLBACK_URL`
- `ORS_API_KEY`
- `RESEND_API_KEY`
- `RESEND_FROM_EMAIL`
- `ADMIN_EMAIL`
- pricing variables

Never prefix a secret with `VITE_`.

## Pricing

Default pricing values are environment variables so you can change the business rules without rewriting the application.

The initial engine uses:

`base vehicle fee + road distance × vehicle km rate`

and a simple heavy-weight surcharge.

These are starter values only. Replace them with FEMADEXDRIVE's real pricing policy.

## Deployment

The root `netlify.toml` builds `frontend/` and serves functions from `backend/netlify/functions`.

Run locally:

```bash
cd frontend
npm install
npm run dev
```

Build:

```bash
cd frontend
npm install
npm run build
```

The supplied environment variables must be configured before the real Supabase/Paystack/routing/email flows can operate.

## Important production checks before accepting real customers

- Verify your Paystack business account and live credentials.
- Configure and test the Paystack webhook.
- Verify your Paystack redirect URL.
- Verify the ORS routing key and usage limits.
- Configure a verified Resend sender/domain when moving beyond testing.
- Set the real admin hostname.
- Promote exactly the intended operations account to `admin`.
- Test Supabase RLS with customer, rider and admin accounts separately.
- Test failed, pending, duplicated and successful payment webhooks.
- Test an order that is rejected by rider eligibility.
- Test customer delivery confirmation and the five-minute auto-confirmation job separately.
- Add a server-side scheduled job for the five-minute auto-confirmation before launch; the current UI/database foundation intentionally does not pretend a browser timer is reliable for this.

## No credentials are included

This package intentionally leaves Supabase, Paystack, routing and email credentials blank for you to fill in.


## Delivery charge model

The browser never sets the final charge. The backend geocodes both addresses, calculates road distance and driving duration through the routing provider, selects a vehicle from package weight/size rules, and calculates the system estimate. The order begins in `price_review`; only an admin/supervisor can release it to `awaiting_payment` by setting the final price. Paystack checkout can only be initialized for an `awaiting_payment` order.

## Customer ↔ rider chat

Each assigned delivery has its own realtime chat room backed by `chat_messages` and Supabase Realtime. RLS allows only the customer and assigned rider to read/write an active delivery chat. Admins can read operational records. Rider/customer contact details are returned through a participant-checked RPC.

## Automatic delivery confirmation

When a rider marks an order `delivered`, the customer has five minutes to confirm. A scheduled Netlify function runs every minute and server-side marks overdue deliveries `completed`, recording an `auto_completed` event.
