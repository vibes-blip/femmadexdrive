import crypto from "node:crypto";
import {sb,userFromRequest,body,json,err} from "./_lib.mjs";

const paystack=async(path,opts={})=>{
  if(!process.env.PAYSTACK_SECRET_KEY) throw new Error("PAYSTACK_SECRET_KEY is not configured.");
  const r=await fetch(`https://api.paystack.co${path}`,{
    ...opts,
    headers:{Authorization:`Bearer ${process.env.PAYSTACK_SECRET_KEY}`,"Content-Type":"application/json",...(opts.headers||{})}
  });
  const d=await r.json();
  if(!r.ok||!d.status) throw new Error(d.message||"Paystack request failed");
  return d;
};

export async function verifyReference(reference){
  const d=await paystack(`/transaction/verify/${encodeURIComponent(reference)}`);
  return d.data;
}

export async function markPayment(data){
  const db=sb();
  const reference=String(data?.reference||"");
  if(!reference) return false;
  const {data:p}=await db.from("payments").select("*").eq("reference",reference).maybeSingle();
  if(!p) return false;
  const amountOk=Number(data.amount)===Math.round(Number(p.amount)*100);
  const currencyOk=String(data.currency||"").toUpperCase()==="NGN";
  const success=data.status==="success"&&amountOk&&currencyOk;
  await db.from("payments").update({
    status:success?"paid":"failed",
    paystack_status:data.status||null,
    fee:data.fees?Number(data.fees)/100:0,
    payment_method:data.channel||data.authorization?.channel||null,
    paid_at:success?new Date().toISOString():null,
    raw_response:data
  }).eq("id",p.id);
  if(success){
    const {data:o}=await db.from("orders").select("id,status").eq("id",p.order_id).maybeSingle();
    if(o && ["awaiting_payment","price_review"].includes(o.status)){
      await db.from("orders").update({payment_status:"paid",status:"paid"}).eq("id",p.order_id).in("status",["awaiting_payment","price_review"]);
      await db.from("order_events").insert({order_id:p.order_id,actor_id:p.customer_id,event:"payment_confirmed",note:`Paystack reference ${reference}`});
      if(process.env.ADMIN_EMAIL){
        const {sendAdmin}=await import("./notify.mjs");
        await sendAdmin(`FEMADEXDRIVE payment received ${reference}`,`<h2>Payment received</h2><p>Reference: ${reference}</p><p>Amount: ₦${Number(p.amount).toLocaleString()}</p><p>Order: ${p.order_id}</p>`).catch(()=>{});
      }
    }
  }
  return success;
}

export default async req=>{
  if(req.method==="OPTIONS") return new Response("",{status:204});
  try{
    const user=await userFromRequest(req), b=await body(req), db=sb();
    const {data:o,error}=await db.from("orders").select("id,tracking_number,customer_id,final_price,status,payment_status").eq("id",b.orderId).eq("customer_id",user.id).maybeSingle();
    if(error||!o) throw new Error("Delivery not found");
    if(o.status!=="awaiting_payment"||o.payment_status!=="unpaid") throw new Error("Operations has not released this delivery for payment yet");
    if(Number(o.final_price)<=0) throw new Error("Invalid delivery price");

    const reference=`FDD-${o.tracking_number}-${crypto.randomUUID().slice(0,8)}`;
    const {data:p,error:pe}=await db.from("payments").insert({order_id:o.id,customer_id:user.id,amount:o.final_price,currency:"NGN",status:"pending",reference}).select("*").single();
    if(pe||!p) throw pe||new Error("Could not create payment record");

    const origin=new URL(req.url).origin;
    const d=await paystack("/transaction/initialize",{
      method:"POST",
      body:JSON.stringify({
        amount:Math.round(Number(o.final_price)*100),
        email:user.email,
        currency:"NGN",
        reference,
        callback_url:process.env.PAYSTACK_CALLBACK_URL||`${origin}/.netlify/functions/paystack-callback`,
        metadata:{order_id:o.id,tracking_number:o.tracking_number},
        channels:["card","bank","ussd","bank_transfer","mobile_money"]
      })
    });
    return json({checkoutUrl:d.data.authorization_url,reference,accessCode:d.data.access_code});
  }catch(e){return err(e)}
};
